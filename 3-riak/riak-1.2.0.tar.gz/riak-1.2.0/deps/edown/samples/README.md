At this point, there are samples in this directory only for the 'markedoc' script, which complements edoc by allowing for converting markdown format to edoc format.
